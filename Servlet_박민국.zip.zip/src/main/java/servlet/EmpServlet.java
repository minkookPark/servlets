package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import JDBC.Dept;
import JDBC.Emp;
import JDBC.JDBC_Dept;
import JDBC.JDBC_Emp;



@WebServlet("/emp/*")
public class EmpServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		process(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		process(req, resp);
	}

	private void process(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String action = getAction(req);

		if (action.equals("input")) 
		{			
			System.out.println("input");
			JDBC_Dept dDao = new JDBC_Dept();
			
			List<Dept> dLst = dDao.findAll();			
			req.setAttribute("dLst", dLst);
		}
		else if (action.equals("save")) 
		{
			System.out.println("save");
			JDBC_Emp eDao = new JDBC_Emp();
			
			String name = req.getParameter("name");
			String job = req.getParameter("job");
			String strSal = req.getParameter("sal");
			int sal = Integer.parseInt(strSal);
			String strDeptno = req.getParameter("deptno");
			int deptno = Integer.parseInt(strDeptno);
			
			Emp e = new Emp(name, job, sal, deptno);
			System.out.println(e);
			
			eDao.insert(e);
			
		}
	
		else if (action.equals("update"))
		{
			System.out.println("update");
			
			JDBC_Emp eDao = new JDBC_Emp();
			
			Emp e = new Emp();
			e.seteName(action);
			
			System.out.println(req.getParameter("emp"));
			//memo.setContent(req.getParameter("content"));
			
			
			//System.out.println(memo);
			
			
			//업데이트 실행
			//dao.update(memo);
			
			
		}
		else if (action.equals("detail"))
		{
			JDBC_Emp eDao = new JDBC_Emp();
			Emp e = eDao.findByIndex(Integer.parseInt(req.getParameter("empNo")));			
			System.out.println(e);
			req.setAttribute("empNo", e);
		}
		else if (action.equals("list"))
		{
			System.out.println("list");
			JDBC_Emp eDao = new JDBC_Emp();
			List<Emp> eLst = eDao.findAll();
			req.setAttribute("eLst", eLst);			
			System.out.println(eLst);
		}
		else if (action.equals("delete"))
		{
			System.out.println("delete");
			JDBC_Emp eDao = new JDBC_Emp();
		}
		
		
		
///////////////////////////////////////////////

		String dispatchUrl = null;

		if (action.equals("input")) 
		{
			dispatchUrl = "/input.jsp";
			System.out.println("\n" + dispatchUrl);
		}
		else if (action.equals("save")) 
		{
			dispatchUrl = "/save.jsp";
			System.out.println("\n" + dispatchUrl);
		}
		else if (action.equals("update"))
		{
			dispatchUrl = "/update.jsp";
			System.out.println("\n" + dispatchUrl);
		}
		else if (action.equals("list"))
		{
			dispatchUrl = "/list.jsp";
			System.out.println("\n" + dispatchUrl);
		}
		else if (action.equals("detail"))
		{
			dispatchUrl = "/detail.jsp";
			System.out.println("\n" + dispatchUrl);
		}

		else if (action.equals("delete"))
		{
			dispatchUrl = "/delete.jsp";
			System.out.println("\n" + dispatchUrl);
		}

		RequestDispatcher rd = req.getRequestDispatcher(dispatchUrl);
		System.out.println("rd : " + rd);
		rd.forward(req, resp);

	}

	private String getAction(HttpServletRequest req) {
		// app01/memo/list 등등 여러 주소가 들어 올 수 있다.
		String uri = req.getRequestURI();
		// 문자열의 마지막 / 를 가져온다. (인덱스를 가져옴)
		int lastIndex = uri.lastIndexOf("/");
		// 마지막 / 뒤의 문자 다 가져오는 기능.
		String action = uri.substring(lastIndex + 1);

		return action;
	}
}
