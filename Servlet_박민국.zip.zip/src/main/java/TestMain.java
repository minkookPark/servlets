import java.sql.Date;

import JDBC.Dept;
import JDBC.Emp;
import JDBC.JDBC_Dept;
import JDBC.JDBC_Emp;

public class TestMain {
	public static void main(String[] args) {
		
		//Dept Insert Test 테스트 완료
		//JDBC_Dept dDao = new JDBC_Dept();
//		Dept d = new Dept();
//		d.setDeptNo(55);
//		d.setdName("노예");
//		d.setLoc("불지옥");
//		dDao.insert(d);
		
		//findall 테스트 완료
//		for(Dept d : dDao.findAll())
//		{
//			System.out.println(d);
//		}
		
		//findbyindex 테스트 완료
//		Dept d = dDao.findByIndex(10);
//		System.out.println(d);
		
		//update 테스트 완료
//		Dept d = new Dept();
//		d.setDeptNo(55);
//		d.setdName("하수인");
//		d.setLoc("hell");
//		dDao.update(d);
		
		//delete 테스트 완료
		//dDao.delete(55);

		
		//////////////////////emp
		//insert 테스트 완료
		JDBC_Emp eDao = new JDBC_Emp();
//		Emp e = new Emp();
//		e.setDeptNo(10);
//		e.setEmpNo(10);
//		e.seteName("하수인");
//
//		e.setJob("노예");
//		e.setSal(100);
//		eDao.insert(e);
		
		//findall 테스트 완료
//		for(Emp d : eDao.findAll())
//		{
//			System.out.println(d);
//		}
		
		//findbyindex 테스트 완료
//		Emp e = eDao.findByIndex(10);
//		System.out.println(e);
		
		//update 테스트 완료
		Emp e = new Emp();

		
		e.seteName("퍼리");
		e.setJob("노예");
		e.setSal(5000);
		e.setDeptNo(30);
		eDao.insert(e);
//		
//		eDao.update(e);
		
		//delete 테스트 완료

//		eDao.delete(1);
//		eDao.delete(10);
//		int a= eDao.getNextIndex();
//		System.out.println(a);
		
		
		
		
		
	}
}
