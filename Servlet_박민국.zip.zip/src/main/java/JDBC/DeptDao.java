package JDBC;

import java.util.List;


public interface DeptDao {
    boolean insert(Dept dept);
    List<Dept> findAll();
    Dept findByIndex(int index);    
    boolean update(Dept dept);
    boolean delete(int number);
}
