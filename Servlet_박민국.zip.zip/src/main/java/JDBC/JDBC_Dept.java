package JDBC;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import DataSource.DataSource;


public class JDBC_Dept implements DeptDao{

	@Override
	public boolean insert(Dept dept) {
	       boolean result = false;
	        //try 문이 끝나면 자동으로 close 된다.
	        try(Connection conn = DataSource.getDataSource();
	            PreparedStatement pStatement = conn.prepareStatement(
	                    "INSERT Into dept(deptno, dname, loc) values(?,?,?)"))
	        {
	            //삽입
	            //pStatement.setString(1,dept.getContent());
	        	pStatement.setInt(1, dept.getDeptNo());
	        	pStatement.setString(2, dept.getdName());
	        	pStatement.setString(3, dept.getLoc());

	            int rows = pStatement.executeUpdate();

	            if(rows > 0)
	            {
	                result = true;
	            }

	        }
	        catch(SQLException e)
	        {
	            e.printStackTrace();
	        }
	        
	        return result;
	}

	@Override
	public List<Dept> findAll() {
        List<Dept> dLst = new ArrayList<>();
        try (Connection conn = DataSource.getDataSource();
             PreparedStatement pStatement = conn.prepareStatement("select * from dept order by Deptno desc");
             ResultSet rs = pStatement.executeQuery())
        {
            while (rs.next())
            {            	
            	Dept d = new Dept();
            	d.setDeptNo(rs.getInt("DEPTNO"));
            	d.setdName(rs.getString("DNAME"));
            	d.setLoc(rs.getString("LOC"));
            	dLst.add(d);
            }

            if(dLst.isEmpty())
            {
                System.out.println("테이블이 비어있습니다.");
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return dLst;
	}

	@Override
	public Dept findByIndex(int index) {
		Dept d = null;
        try (Connection conn = DataSource.getDataSource();
             PreparedStatement pStatement = conn.prepareStatement("select * from dept where deptno = ?"))
        {
            pStatement.setInt(1,index);
            ResultSet rs = pStatement.executeQuery();
            if (rs.next())
            {
                d = new Dept();
                
                d.setDeptNo(rs.getInt("DEPTNO"));
                d.setdName(rs.getString("DNAME"));
                d.setLoc(rs.getString("LOC"));                
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return d;
	}

	@Override
	public boolean update(Dept dept) {
        boolean result = false;

        try (Connection conn = DataSource.getDataSource();
             PreparedStatement pStatement =
                     conn.prepareStatement("update dept "
                     		+ "set dname = ?, loc = ? where deptno = ?"))
        {

            pStatement.setString(1, dept.getdName());
            pStatement.setString(2, dept.getLoc());
            pStatement.setInt(3, dept.getDeptNo());

            int affectedrows = pStatement.executeUpdate();

            if(affectedrows > 0)
            {
                System.out.println("변경 성공!");
                result = true;
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
            System.out.println("변경 실패!");
            result = false;
        }

        return result;
	}

	@Override
	public boolean delete(int number) {
		boolean result = false;

		try (Connection conn = DataSource.getDataSource();
				PreparedStatement pStatement = conn.prepareStatement("delete from dept where deptno = ?")) 
		{
			pStatement.setInt(1, number);
			int rows = pStatement.executeUpdate();
			if(rows > 0)
				result = true;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			System.out.println("삭제 실패!");
			result = false;
		}

		return result;
	}

}
