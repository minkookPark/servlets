package JDBC;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import DataSource.DataSource;

public class JDBC_Emp implements EmpDao {

	@Override
	public boolean insert(Emp emp) {
		boolean result = false;
		// try 문이 끝나면 자동으로 close 된다.
		try (Connection conn = DataSource.getDataSource();
				PreparedStatement pStatement = conn.prepareStatement(
						"INSERT Into emp(empno, ename, job, hiredate, sal, deptno) values(?,?,?,SYSDATE,?,?)")) {
			pStatement.setInt(1, getNextIndex());
			pStatement.setString(2, emp.geteName());
			pStatement.setString(3, emp.getJob());
			pStatement.setInt(4, emp.getSal());
			pStatement.setInt(5, emp.getDeptNo());

			int rows = pStatement.executeUpdate();

			if (rows > 0) {
				result = true;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return result;
	}

	public int getNextIndex() {
		int lastIndex = 0;

		try (Connection conn = DataSource.getDataSource();
				PreparedStatement pStatement = conn.prepareStatement(
						"SELECT MAX(empno) AS max_empno FROM emp")) {
			ResultSet rs = pStatement.executeQuery();

			if (rs.next()) {
				lastIndex = rs.getInt("max_empno");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		lastIndex++ ;

		return lastIndex;
	}

	@Override
	public List<Emp> findAll() {
		List<Emp> eLst = new ArrayList<>();
		try (Connection conn = DataSource.getDataSource();
				PreparedStatement pStatement = conn.prepareStatement("select * from emp order by empno desc");
				ResultSet rs = pStatement.executeQuery()) {
			while (rs.next()) {
				Emp e = new Emp();
				e.setEmpNo(rs.getInt("Empno"));
				e.seteName(rs.getString("ENAME"));
				e.setHireDate(rs.getDate("HIREDATE"));
				e.setJob(rs.getString("job"));
				e.setSal(rs.getInt("sal"));
				e.setDeptNo(rs.getInt("deptno"));
				eLst.add(e);
			}

			if (eLst.isEmpty()) {
				System.out.println("테이블이 비어있습니다.");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return eLst;
	}

	@Override
	public Emp findByIndex(int index) {
		Emp e = null;
		try (Connection conn = DataSource.getDataSource();
				PreparedStatement pStatement = conn.prepareStatement("select * from emp where empno = ?")) {
			pStatement.setInt(1, index);
			ResultSet rs = pStatement.executeQuery();
			if (rs.next()) {
				e = new Emp();

				e.setEmpNo(rs.getInt("Empno"));
				e.seteName(rs.getString("ENAME"));
				e.setHireDate(rs.getDate("HIREDATE"));
				e.setJob(rs.getString("job"));
				e.setSal(rs.getInt("sal"));
				e.setDeptNo(rs.getInt("deptno"));

			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return e;
	}

	@Override
	public boolean update(Emp emp) {
		// update emp set ename = 'aaa', job = 'qewr', sal = 10 where empno = 10;

		boolean result = false;

		try (Connection conn = DataSource.getDataSource();
				PreparedStatement pStatement = conn.prepareStatement(
						"update emp " + "set ename = ?, job = ?, sal = ?, deptno = ? where empno = ?")) {

			pStatement.setString(1, emp.geteName());
			pStatement.setString(2, emp.getJob());
			pStatement.setInt(3, emp.getSal());
			pStatement.setInt(4, emp.getDeptNo());
			pStatement.setInt(5, emp.getEmpNo());

			int affectedrows = pStatement.executeUpdate();

			if (affectedrows > 0) {
				System.out.println("변경 성공!");
				result = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("변경 실패!");
			result = false;
		}

		return result;
	}

	@Override
	public boolean delete(int empno) {
		boolean result = false;

		try (Connection conn = DataSource.getDataSource();
				PreparedStatement pStatement = conn.prepareStatement("delete from emp where empno = ?")) {
			pStatement.setInt(1, empno);
			int rows = pStatement.executeUpdate();
			if (rows > 0)
				result = true;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("삭제 실패!");
			result = false;
		}

		return result;
	}

}
