package JDBC;

import java.util.List;

public interface EmpDao {
    boolean insert(Emp emp);
    List<Emp> findAll();
    Emp findByIndex(int index);
    boolean update(Emp emp);
    boolean delete(int empno);
}
