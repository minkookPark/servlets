package JDBC;

import java.sql.Date;

public class Emp {

	private int empNo;
	private String eName;
	private String job;
	private Date hireDate;
	private int sal;
	private int deptNo;	
	
	public Emp() {	
	}	
	
	public Emp(String eName, String job, int sal, int deptNo) {		
		this.eName = eName;
		this.job = job;
		this.sal = sal;
		this.deptNo = deptNo;
	}

	public Emp(int empNo, String eName, String job, int sal, int deptNo) {		
		this.empNo = empNo;
		this.eName = eName;
		this.job = job;
		this.sal = sal;
		this.deptNo = deptNo;
	}

	public Emp(int empNo, String eName, String job, Date hireDate, int sal, int deptNo) 
	{	
		this.empNo = empNo;
		this.eName = eName;
		this.job = job;
		this.hireDate = hireDate;
		this.sal = sal;
		this.deptNo = deptNo;
	}
	
	public int getEmpNo() {
		return empNo;
	}
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	public String geteName() {
		return eName;
	}
	public void seteName(String eName) {
		this.eName = eName;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public Date getHireDate() {
		return hireDate;
	}
	public void setHireDate(Date hireDate) {
		this.hireDate = hireDate;
	}
	public int getSal() {
		return sal;
	}
	public void setSal(int sal) {
		this.sal = sal;
	}
	public int getDeptNo() {
		return deptNo;
	}
	public void setDeptNo(int deptNo) {
		this.deptNo = deptNo;
	}


	@Override
	public String toString() {
		return "Emp [empNo=" + empNo + ", eName=" + eName + ", job=" + job + ", hireDate=" + hireDate + ", sal=" + sal
				+ ", deptNo=" + deptNo + "]";
	}
	
	
	
	
	
}
